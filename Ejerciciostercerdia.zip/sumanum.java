import java.util.Scanner;


class par {
  public static void main(String[] args) {

  Scanner scanner = new Scanner(System.in);

  while (true){

    System.out.println("Ingrese el numero: ");
    int num = scanner.nextInt();

      
    }


  }
}